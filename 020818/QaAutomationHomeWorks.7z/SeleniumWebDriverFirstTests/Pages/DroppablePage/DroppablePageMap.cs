﻿namespace SeleniumWebDriverFirstTests.Pages.DroppablePage
{
    using OpenQA.Selenium;
    using OpenQA.Selenium.Support.UI;
    using System.Collections.Generic;
    using System.Linq;
    public partial class DroppablePage
    {

    }
}
