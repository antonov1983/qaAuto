﻿namespace ClassesDemo
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            Person ivan = new Person();

        }
    }
}
